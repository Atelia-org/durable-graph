from pathlib import Path
import json,statistics as s
r=Path(__file__).parent
rows=[json.loads(l) for l in (r/'lockstep'/'lockstep.jsonl').read_text().splitlines()]
assert len(rows)==12
groups={}
for route in ['builtin','leaf']:
    items=[i for i in rows if i['lane']==route]
    groups[route]=items
    assert all(i['cpu']==items[0]['cpu'] for i in items)
    print(route,'logical_cpu',items[0]['cpu'])
    for f in ['hot','edit','save','cold']:
        print(f,'time',s.median(i[f]['Microseconds'] for i in items),'B',s.median(i[f]['Bytes'] for i in items))
    for f in ['saveCpuCycles','editCpuCycles']:
        print(f,s.median(i[f] for i in items))
diffs=[]; pct=[]; cpu=[]; first=[]; second=[]; cpu1=[]; cpu2=[]
for p in range(6):
    a,b=groups['builtin'][p],groups['leaf'][p]
    assert a['pair']==b['pair']==p+1 and a['cpu']==b['cpu']
    ds=[]; ps=[]; cs=[]
    for step,(x,y) in enumerate(zip(a['samples'],b['samples']),6):
        ds.append(y['Microseconds']-x['Microseconds'])
        ps.append(100*(y['Microseconds']/x['Microseconds']-1))
        cs.append(100*(b['cpuSaves'][step-6]/a['cpuSaves'][step-6]-1))
        (second if (step+p)%2==0 else first).append(ps[-1])
        (cpu2 if (step+p)%2==0 else cpu1).append(cs[-1])
    diffs.extend(ds);pct.extend(ps);cpu.extend(cs)
    print('pair',p+1,'us',round(s.median(ds),2),'percent',round(s.median(ps),2),'save_cpu_pct',round(s.median(cs),2))
print(len(diffs),'matched steps: median delta-us, percent, saveCPU-percent',round(s.median(diffs),2),round(s.median(pct),2),round(s.median(cpu),2))
print('leaf-first and second: ms %, CPU %',s.median(first),s.median(second),s.median(cpu1),s.median(cpu2))


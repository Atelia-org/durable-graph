from pathlib import Path
import subprocess,os,sys,json,hashlib
root=Path(__file__).parent
stage=root/'lockstep'
stage.mkdir()
prior=root/'paired'
src=(prior/'builtin/Program.cs').read_text(encoding='utf8')
src=src.replace('const int leafCount', '''var process = Process.GetCurrentProcess();
long allowed = process.ProcessorAffinity.ToInt64();
int cpu = Enumerable.Range(0, 63).Where(i => (allowed & (1L << i)) != 0).Skip(3).First();
process.ProcessorAffinity = (nint)(1L << cpu);
const int leafCount''')
src=src.replace('ulong cpuStart = ThreadClock.Read(handle);','''Console.WriteLine($"ready {step}");
        if (Console.ReadLine() != "go") throw new InvalidDataException("lost start signal");
        ulong cpuStart = ThreadClock.Read(handle);''')
src=src.replace('saveCpuCycles.Add(cpuSaved-cpuEdited);\n        }','''saveCpuCycles.Add(cpuSaved-cpuEdited);
        }
        Console.WriteLine($"done {step}");''')
src=src.replace('var reads = new List<Sample>();','''Console.WriteLine("ready cold");
if (Console.ReadLine() != "go") throw new InvalidDataException("lost cold signal");
var reads = new List<Sample>();''')
src=src.replace('edit = Sample.Median(edits), save = Sample.Median(saves),','edit = Sample.Median(edits), save = Sample.Median(saves), cpu, samples = cycles, editSamples = edits, saveSamples = saves, cpuSaves=saveCpuCycles, cpuEdits=editCpuCycles,')
assert 'done {step}' in src and 'samples = cycles' in src
for lane in ('builtin','leaf'):
    p=stage/lane;p.mkdir()
    (p/'Program.cs').write_text(src,encoding='utf8')
    (p/'Fanout.csproj').write_bytes((prior/lane/'Fanout.csproj').read_bytes())
    with (p/'build.log').open('w',encoding='utf8') as log:
        subprocess.run(['dotnet','build',str(p/'Fanout.csproj'),'-c','Release','-m:1','-nr:false',f'-p:GraphRoot={root/"coexist"}',f'-p:RegisteredLeaf={str(lane=="leaf").lower()}','-p:UseStorageSources=true',f'-p:StorageSourceRoot={root/"storage"}'],stdout=log,stderr=subprocess.STDOUT,check=True)
env=os.environ.copy();env["DOTNET_TieredCompilation"]="0"
for i in range(6):
    children={}
    def read(lane,expected):
        line=children[lane].stdout.readline().strip()
        assert line==expected, (i,lane,repr(line),expected,children[lane].poll())
    def step(lane):
        children[lane].stdin.write('go\n')
        children[lane].stdin.flush()
    try:
        for lane in ('builtin','leaf'):
            exe=stage/lane/'bin/Release/net10.0/RegisteredLeaf.Fanout.dll'
            children[lane]=subprocess.Popen(['dotnet',str(exe),str(stage/f'store-{i}-{lane}')],env=env,encoding='utf8',stdin=subprocess.PIPE,stdout=subprocess.PIPE)
        for cycle in range(30):
            a,b=('builtin','leaf') if (i+cycle)%2==0 else ('leaf','builtin')
            for lane in [a,b]:read(lane,f'ready {cycle}')
            for lane in [a,b]:
                step(lane)
                read(lane,f'done {cycle}')
        for lane in ['builtin','leaf']: read(lane,'ready cold')
        for lane in (('builtin','leaf') if i%2==0 else ('leaf','builtin')):
            step(lane)
            row=json.loads(children[lane].stdout.readline());row.update(lane=lane,pair=i+1)
            assert children[lane].wait()==0
            with (stage/'lockstep.jsonl').open('a',encoding='utf8') as out:out.write(json.dumps(row)+'\n')
    finally:
        for child in children.values():
            if child.poll() is None: child.kill();child.wait()
print('lockstep complete',hashlib.sha256(src.encode()).hexdigest())


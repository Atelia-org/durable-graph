from pathlib import Path
import subprocess,os,sys,json,time,hashlib
root=Path(__file__).parent
probe=root/'coexist/experiments/RegisteredLeafProbe/Fanout'
stage=root/'paired'
stage.mkdir()
src=(probe/'Program.cs').read_text(encoding='utf-8-sig')
src=src.replace('var cycles = new List<Sample>();','''var cycles = new List<Sample>();
var edits = new List<Sample>();
var saves = new List<Sample>();
var editCpuCycles = new List<ulong>();
var saveCpuCycles = new List<ulong>();
var handle = ThreadClock.GetCurrentThread();
ThreadClock.Read(handle);''')
src=src.replace('long allocated = GC.GetAllocatedBytesForCurrentThread(), start = Stopwatch.GetTimestamp();\n        var body', '''ulong cpuStart = ThreadClock.Read(handle);
        long allocated = GC.GetAllocatedBytesForCurrentThread(), start = Stopwatch.GetTimestamp();
        var body''')
src=src.replace('last = repo.SaveGraph(graph);\n        var cycle = Sample.End(start, allocated);\n        if (step >= warm) cycles.Add(cycle);','''long edited = Stopwatch.GetTimestamp(), editAllocated = GC.GetAllocatedBytesForCurrentThread();
        ulong cpuEdited = ThreadClock.Read(handle);
        last = repo.SaveGraph(graph);
        long saved = Stopwatch.GetTimestamp(), savedAllocated = GC.GetAllocatedBytesForCurrentThread();
        ulong cpuSaved = ThreadClock.Read(handle);
        if (step >= warm) {
            cycles.Add(new(Stopwatch.GetElapsedTime(start,saved).TotalMicroseconds,savedAllocated-allocated));
            edits.Add(new(Stopwatch.GetElapsedTime(start,edited).TotalMicroseconds,editAllocated-allocated));
            saves.Add(new(Stopwatch.GetElapsedTime(edited,saved).TotalMicroseconds,savedAllocated-editAllocated));
            editCpuCycles.Add(cpuEdited-cpuStart);
            saveCpuCycles.Add(cpuSaved-cpuEdited);
        }''')
src=src.replace('hot = Sample.Median(cycles), cold = Sample.Median(reads)','''hot = Sample.Median(cycles), cold = Sample.Median(reads),
    edit = Sample.Median(edits), save = Sample.Median(saves),
    editCpuCycles = editCpuCycles.Order().ElementAt(measured/2),
    saveCpuCycles = saveCpuCycles.Order().ElementAt(measured/2)''')
assert 'cpuSaved-cpuEdited' in src
src+='''
static class ThreadClock {
    [System.Runtime.InteropServices.DllImport("kernel32.dll")] internal static extern nint GetCurrentThread();
    [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError=true)]
    static extern bool QueryThreadCycleTime(nint thread, out ulong ticks);
    internal static ulong Read(nint handle) => QueryThreadCycleTime(handle,out var ticks) ? ticks : throw new System.ComponentModel.Win32Exception();
}
'''
for lane in ('builtin','leaf'):
    p=stage/lane;p.mkdir()
    (p/'Program.cs').write_text(src,encoding='utf8')
    (p/'Fanout.csproj').write_bytes((probe/'Fanout.csproj').read_bytes())
    with (p/'build.log').open('w',encoding='utf8') as log:
        subprocess.run(['dotnet','build',str(p/'Fanout.csproj'),'-c','Release','-m:1','-nr:false',f'-p:GraphRoot={root/"coexist"}',f'-p:RegisteredLeaf={str(lane=="leaf").lower()}','-p:UseStorageSources=true',f'-p:StorageSourceRoot={root/"storage"}'],stdout=log,stderr=subprocess.STDOUT,check=True)
env=os.environ.copy();env["DOTNET_TieredCompilation"]="0"
for i, lanes in enumerate([('builtin','leaf'),('leaf','builtin'),('builtin','leaf'),('leaf','builtin'),('builtin','leaf'),('leaf','builtin')]):
    for lane in lanes:
        exe=stage/lane/'bin/Release/net10.0/RegisteredLeaf.Fanout.dll'
        start=time.time()
        raw=subprocess.check_output(['dotnet',str(exe),str(stage/f'store-{i}-{lane}')],env=env,encoding='utf8')
        row=json.loads(raw);row.update(lane=lane,pair=i+1,position=lanes.index(lane)+1,startUnix=start,elapsed=time.time()-start)
        with (stage/'paired.jsonl').open('a',encoding='utf8') as out:out.write(json.dumps(row)+'\n')
print('paired complete',hashlib.sha256(src.encode()).hexdigest())


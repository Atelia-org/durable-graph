using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Atelia.DurableGraph;
using Atelia.DurableGraph.Persistence;
using Atelia.DurableGraph.Storage;
using Atelia.FrameStore;
using Atelia.HeadStore;

var output = new List<object>();
List<(uint Id, int Bytes, string Hash)>? baseline = null;
foreach (string dir in Directory.GetDirectories(args[0], "store-*").OrderBy(n => n, StringComparer.Ordinal)) {
    using var repo = Repository.OpenReadOnlyExisting(dir, new StateModelRegistry());
    const BindingFlags access = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    var resources = typeof(Repository).GetField("_resources", access)!.GetValue(repo)!;
    var tip = (HeadEntryId)resources.GetType().GetMethod("ReadHeapTip", access)!.Invoke(resources, null)!;
    var heads = (HeadStore)resources.GetType().GetField("_heads", access)!.GetValue(resources)!;
    var ids = new List<HeadEntryId>();
    var history = heads.ReadEntryHistory(tip, new HeadHistoryBudget(100,2000), row => {
        if (!row.Payload.SequenceEqual("P0HE"u8)) ids.Add(row.Id);
        return true;
    });
    if (history.IsFailure || ids.Count != 31) throw new InvalidDataException("Missing fanout entries.");
    ids.Reverse();
    var store = Property(repo, "GraphStore");
    var previous = new Dictionary<uint, FrameAddress>();
    var fixes = new List<(uint Id, int Bytes, string Hash)>();
    int baseBytes = 0, baseRows = 0;
    foreach (var id in ids) {
        var descriptor = Invoke(resources, "ReadHeapDescriptor", id);
        var revision = Invoke(store, "ReadBusinessGraph", Property(descriptor, "Address"));
        var batch = (FrameAddress)Property(revision, "OwnedBatch");
        var rows = (IReadOnlyList<ObjectVersionRecord>)Property(Invoke(store, "ReadBatch", batch), "Records");
        if (previous.Count == 0) {
            if (rows.Count != 130 || rows.Any(r => r.Kind != ObjectVersionKind.Base || r.PriorAddress != null))
                throw new InvalidDataException("Initial list, root, and 128 leaves must have Bases.");
            foreach (var row in rows) previous.Add(row.ObjectId, batch);
            baseBytes = rows.Sum(r => r.Body.Length);
            baseRows = rows.Count;
            continue;
        }
        var edit = rows.Single();
        if (edit.Kind != ObjectVersionKind.Delta || edit.PriorAddress != previous[edit.ObjectId])
            throw new InvalidDataException("The changed leaf must use its own exact prior record.");
        if (fixes.Count >= 6 && edit.ObjectId != fixes[fixes.Count - 6].Id) throw new InvalidDataException("Target rotated incorrectly.");
        previous[edit.ObjectId] = batch;
        fixes.Add((edit.ObjectId,edit.Body.Length,Convert.ToHexString(SHA256.HashData(edit.Body))));
    }
    if (fixes.Select(f => f.Id).Distinct().Count() != 6 || fixes.Count != 30) throw new InvalidDataException("Wrong number of touched leaves.");
    if (baseline != null && !fixes.SequenceEqual(baseline)) throw new InvalidDataException("Delta content differs across runs.");
    baseline ??= fixes;
    output.Add(new { store = Path.GetFileName(dir), baseRows, baseBytes, deltaRows=fixes.Count, deltaBytes=fixes.Sum(f=>f.Bytes), exactPredecessors=true, sameBodies=true });
}
if (output.Count != 9) throw new InvalidDataException("Expected nine physical repositories.");
Console.WriteLine(JsonSerializer.Serialize(new { stores=output, deltas=baseline!.Select(f => new { f.Id, f.Bytes, f.Hash }) }, new JsonSerializerOptions{ WriteIndented=true }));

static object Property(object obj, string name) => obj.GetType().GetProperty(name, BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)!.GetValue(obj)!;
static object Invoke(object obj, string name, object arg) => obj.GetType().GetMethod(name, BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic, null, [arg.GetType()], null)!.Invoke(obj, [arg])!;

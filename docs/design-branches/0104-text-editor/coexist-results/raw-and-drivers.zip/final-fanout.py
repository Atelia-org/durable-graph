from pathlib import Path
import json,os,shutil,subprocess,hashlib
root=Path(__file__).parent
stage=root/'final-runner';stage.mkdir()
for n in ['Fanout.csproj','Program.cs']: shutil.copyfile(root/'coexist/experiments/RegisteredLeafProbe/Fanout'/n,stage/n)
env=os.environ.copy();env['DOTNET_TieredCompilation']='0'
with (stage/'build.log').open('w',encoding='utf8') as log:
    subprocess.run(['dotnet','build',str(stage/'Fanout.csproj'),'-c','Release','-m:1','-nr:false',f'-p:GraphRoot={root/"final"}','-p:RegisteredLeaf=true','-p:UseStorageSources=true',f'-p:StorageSourceRoot={root/"storage"}'],stdout=log,stderr=subprocess.STDOUT,check=True)
for n in range(3):
    with (stage/'fanout.jsonl').open('a',encoding='utf8') as out:
        raw=subprocess.check_output(['dotnet',str(stage/'bin/Release/net10.0/RegisteredLeaf.Fanout.dll'),str(stage/f'store-{n}-final')],env=env,encoding='utf8')
        row=json.loads(raw);row['run']=n+1
        out.write(json.dumps(row)+'\n')
audit=stage/'audit';audit.mkdir()
src=(root/'audit/Program.cs').read_text(encoding='utf8')
src=src.replace('Directory.GetDirectories(args[0], "store-*").OrderBy(n => n, StringComparer.Ordinal)','args')
src=src.replace('output.Count != 9','output.Count != 4').replace('Expected nine physical repositories.','Expected final three and one original repository.')
(audit/'Program.cs').write_text(src,encoding='utf8')
(audit/'Audit.csproj').write_bytes((root/'audit/Audit.csproj').read_bytes())
with (audit/'build.log').open('w',encoding='utf8') as log:
    subprocess.run(['dotnet','build',str(audit/'Audit.csproj'),'-c','Release','-m:1',f'-p:AssemblyDirectory={stage/"bin/Release/net10.0"}'],stdout=log,stderr=subprocess.STDOUT,check=True)
with (stage/'audit.json').open('w',encoding='utf8') as out:
    paths=[root/'fanout/store-0-lab-builtin',*(stage/f'store-{n}-final' for n in range(3))]
    subprocess.run(['dotnet',str(audit/'bin/Release/net10.0/Audit.dll'),*map(str,paths)],stdout=out,check=True)
print('final checks passed')


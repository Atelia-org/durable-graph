from pathlib import Path
import json,statistics as s
from collections import defaultdict
root=Path(__file__).parent
rows=[json.loads(l) for l in (root/'paired'/'paired.jsonl').read_text().splitlines()]
assert len(rows)==12
for lane in ['builtin','leaf']:
    items=[i for i in rows if i['lane']==lane]
    print(lane)
    for field in ['edit','save','hot','cold']:
        seq=[i[field]['Microseconds'] for i in items]
        print(field,round(s.median(seq),2),min(seq),max(seq),s.median(i[field]['Bytes'] for i in items))
    for field in ['editCpuCycles','saveCpuCycles']:
        print(field,s.median(i[field] for i in items))
for p in range(1,7):
    orig,leaf=sorted([i for i in rows if i['pair']==p],key=lambda i:i['lane'])
    print(p,orig['position'],orig['hot']['Microseconds'],leaf['hot']['Microseconds'],round(100*(leaf['hot']['Microseconds']/orig['hot']['Microseconds']-1),2),orig['saveCpuCycles'],leaf['saveCpuCycles'])

